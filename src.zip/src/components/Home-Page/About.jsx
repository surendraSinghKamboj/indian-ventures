import React from 'react'
import WeAre from '../WeAre'
function About() {
  return (
    <div>
      <WeAre/>
    </div>
  )
}

export default About
