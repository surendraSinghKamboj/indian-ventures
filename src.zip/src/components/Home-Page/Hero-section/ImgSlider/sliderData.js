import img_one from "../../../../assets/img1.png";
import img_two from "../../../../assets/img2.png";
import img_three from "../../../../assets/img3.png";


export const slides = [
    {
        src:img_one,
        alt:"slide on"
    },
    {
        src:img_two,
        alt:"slides second"
    },
    {
        src:img_three,
        alt:"slide third"
    }
]
